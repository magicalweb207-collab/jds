// utils/revenue.js — Automatic 90% Revenue Distribution

const db     = require('../config/database');
const redis  = require('../config/redis');
const logger = require('../utils/logger');

const CREATOR_SHARE = parseFloat(process.env.CREATOR_REVENUE_SHARE || 0.90);
const CPM_RATE      = parseFloat(process.env.CPM_RATE || 1.20); // BDT per 1000 views

const revenueService = {

  // ── Credit earning for each video view ──
  creditViewEarning: async (creatorId, videoId) => {
    try {
      const earning = +(CPM_RATE / 1000 * CREATOR_SHARE).toFixed(6);
      await db.query(
        'UPDATE wallets SET balance=balance+$1, total_earned=total_earned+$1 WHERE user_id=$2',
        [earning, creatorId]
      );
      await db.query(
        'UPDATE videos SET earnings=earnings+$1 WHERE id=$2',
        [earning, videoId]
      );
      await db.query(
        `INSERT INTO transactions (user_id, type, amount, description)
         VALUES ($1,'video_view',$2,'ভিডিও ভিউ আয়')`,
        [creatorId, earning]
      );
      await redis.del(`wallet:${creatorId}`);
    } catch (err) {
      logger.error('Credit view earning error:', err.message);
    }
  },

  // ── Daily revenue distribution (run via cron) ──
  dailyDistribution: async () => {
    try {
      const DAILY_AD_REVENUE = 10000; // BDT — replace with actual AdMob revenue
      const CREATOR_POOL = DAILY_AD_REVENUE * CREATOR_SHARE;

      const yesterday = new Date(Date.now() - 86400000).toISOString();

      // Get creator scores from last 24 hours
      const { rows: creators } = await db.query(`
        SELECT
          v.user_id,
          SUM(v.views)          * 1  +
          SUM(v.likes_count)    * 5  +
          SUM(v.comments_count) * 10 +
          SUM(v.shares_count)   * 15 as score
        FROM videos v
        WHERE v.updated_at >= $1
        GROUP BY v.user_id
        HAVING SUM(v.views) > 0
      `, [yesterday]);

      if (!creators.length) return;

      const totalScore = creators.reduce((s, c) => s + parseFloat(c.score), 0);
      if (totalScore === 0) return;

      for (const creator of creators) {
        const share    = parseFloat(creator.score) / totalScore;
        const capped   = Math.min(share, 0.30); // max 30% per creator
        const amount   = +(CREATOR_POOL * capped).toFixed(2);
        if (amount < 1) continue;

        await db.query(
          'UPDATE wallets SET balance=balance+$1, total_earned=total_earned+$1 WHERE user_id=$2',
          [amount, creator.user_id]
        );
        await db.query(
          `INSERT INTO transactions (user_id, type, amount, description)
           VALUES ($1,'ad_share',$2,'দৈনিক বিজ্ঞাপন আয় বিতরণ')`,
          [creator.user_id, amount]
        );
        await redis.del(`wallet:${creator.user_id}`);
      }

      logger.info(`✅ দৈনিক রেভিনিউ বিতরণ: ৳${CREATOR_POOL.toFixed(2)} — ${creators.length} ক্রিয়েটর`);
    } catch (err) {
      logger.error('Daily distribution error:', err.message);
    }
  },

  // ── Referral bonus ──
  creditReferral: async (referrerId, newUserId) => {
    try {
      const BONUS = 50; // BDT per referral
      await db.query(
        'UPDATE wallets SET balance=balance+$1, total_earned=total_earned+$1 WHERE user_id=$2',
        [BONUS, referrerId]
      );
      await db.query(
        `INSERT INTO transactions (user_id, type, amount, description)
         VALUES ($1,'referral',$2,'রেফারেল বোনাস')`,
        [referrerId, BONUS]
      );
      await redis.del(`wallet:${referrerId}`);
      logger.info(`💰 রেফারেল বোনাস: ৳${BONUS} → ${referrerId}`);
    } catch (err) {
      logger.error('Referral error:', err.message);
    }
  },
};

// ── Schedule daily distribution at midnight ──
const scheduleDailyDistribution = () => {
  const now   = new Date();
  const night = new Date(now);
  night.setHours(24, 0, 0, 0);
  const msUntilMidnight = night - now;
  setTimeout(() => {
    revenueService.dailyDistribution();
    setInterval(revenueService.dailyDistribution, 24 * 60 * 60 * 1000);
  }, msUntilMidnight);
  logger.info(`⏰ দৈনিক রেভিনিউ বিতরণ ${Math.floor(msUntilMidnight/3600000)} ঘণ্টা পরে`);
};

scheduleDailyDistribution();

module.exports = revenueService;
