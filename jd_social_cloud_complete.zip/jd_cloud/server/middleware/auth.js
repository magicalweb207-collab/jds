// middleware/auth.js — JWT Authentication

const jwt    = require('jsonwebtoken');
const db     = require('../config/database');
const redis  = require('../config/redis');
const logger = require('../utils/logger');

const auth = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1]
      || req.cookies?.token;

    if (!token) {
      return res.status(401).json({ error: 'লগইন করুন।' });
    }

    // Check token blacklist (logout)
    const isBlacklisted = await redis.get(`blacklist:${token}`);
    if (isBlacklisted) {
      return res.status(401).json({ error: 'সেশন শেষ হয়েছে। আবার লগইন করুন।' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Cache user in Redis
    let user = await redis.getJSON(`user:${decoded.id}`);
    if (!user) {
      const { rows } = await db.query(
        'SELECT id, name, username, email, phone, avatar_url, verified, is_admin, is_banned FROM users WHERE id=$1',
        [decoded.id]
      );
      if (!rows[0]) return res.status(401).json({ error: 'ব্যবহারকারী পাওয়া যায়নি।' });
      user = rows[0];
      await redis.setJSON(`user:${decoded.id}`, user, 300);
    }

    if (user.is_banned) {
      return res.status(403).json({ error: 'আপনার অ্যাকাউন্ট নিষিদ্ধ করা হয়েছে।' });
    }

    req.user = user;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'সেশন মেয়াদ শেষ।', expired: true });
    }
    logger.error('Auth middleware error:', err.message);
    return res.status(401).json({ error: 'অবৈধ টোকেন।' });
  }
};

const adminAuth = [auth, (req, res, next) => {
  if (!req.user.is_admin) {
    return res.status(403).json({ error: 'অ্যাডমিন অ্যাক্সেস প্রয়োজন।' });
  }
  next();
}];

const optionalAuth = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1] || req.cookies?.token;
    if (token) {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      let user = await redis.getJSON(`user:${decoded.id}`);
      if (!user) {
        const { rows } = await db.query('SELECT * FROM users WHERE id=$1', [decoded.id]);
        user = rows[0] || null;
      }
      req.user = user;
    }
  } catch (_) {}
  next();
};

module.exports = { auth, adminAuth, optionalAuth };
