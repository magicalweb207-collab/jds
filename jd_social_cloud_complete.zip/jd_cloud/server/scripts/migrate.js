// scripts/migrate.js — Database Tables

require('dotenv').config({ path: '../.env' });
const db = require('../config/database');

const migrations = `

-- ══════════════════════════════════════
-- EXTENSIONS
-- ══════════════════════════════════════
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- ══════════════════════════════════════
-- USERS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS users (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name          VARCHAR(100) NOT NULL,
  username      VARCHAR(50)  UNIQUE NOT NULL,
  email         VARCHAR(255) UNIQUE,
  phone         VARCHAR(20)  UNIQUE,
  password_hash VARCHAR(255),
  avatar_url    TEXT,
  cover_url     TEXT,
  bio           TEXT DEFAULT '',
  verified      BOOLEAN DEFAULT FALSE,
  is_admin      BOOLEAN DEFAULT FALSE,
  is_banned     BOOLEAN DEFAULT FALSE,
  followers_count  INT DEFAULT 0,
  following_count  INT DEFAULT 0,
  video_count      INT DEFAULT 0,
  total_likes      INT DEFAULT 0,
  google_id     VARCHAR(100),
  facebook_id   VARCHAR(100),
  push_token    TEXT,
  last_seen     TIMESTAMPTZ DEFAULT NOW(),
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_email    ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_phone    ON users(phone);

-- ══════════════════════════════════════
-- FOLLOWS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS follows (
  follower_id UUID REFERENCES users(id) ON DELETE CASCADE,
  following_id UUID REFERENCES users(id) ON DELETE CASCADE,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (follower_id, following_id)
);

-- ══════════════════════════════════════
-- VIDEOS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS videos (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID REFERENCES users(id) ON DELETE CASCADE,
  title         VARCHAR(300) NOT NULL,
  description   TEXT DEFAULT '',
  video_url     TEXT NOT NULL,
  thumbnail_url TEXT,
  duration      INT DEFAULT 0,
  width         INT DEFAULT 1080,
  height        INT DEFAULT 1920,
  size_bytes    BIGINT DEFAULT 0,
  views         INT DEFAULT 0,
  likes_count   INT DEFAULT 0,
  comments_count INT DEFAULT 0,
  shares_count  INT DEFAULT 0,
  saves_count   INT DEFAULT 0,
  earnings      DECIMAL(10,4) DEFAULT 0,
  is_public     BOOLEAN DEFAULT TRUE,
  allow_comments BOOLEAN DEFAULT TRUE,
  allow_duet    BOOLEAN DEFAULT TRUE,
  status        VARCHAR(20) DEFAULT 'active',
  tags          TEXT[] DEFAULT '{}',
  hashtags      TEXT[] DEFAULT '{}',
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_videos_user_id   ON videos(user_id);
CREATE INDEX IF NOT EXISTS idx_videos_created   ON videos(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_videos_hashtags  ON videos USING GIN(hashtags);
CREATE INDEX IF NOT EXISTS idx_videos_views     ON videos(views DESC);

-- ══════════════════════════════════════
-- VIDEO LIKES
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS video_likes (
  video_id   UUID REFERENCES videos(id) ON DELETE CASCADE,
  user_id    UUID REFERENCES users(id)  ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (video_id, user_id)
);

-- ══════════════════════════════════════
-- COMMENTS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS comments (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  video_id    UUID REFERENCES videos(id) ON DELETE CASCADE,
  user_id     UUID REFERENCES users(id)  ON DELETE CASCADE,
  parent_id   UUID REFERENCES comments(id) ON DELETE CASCADE,
  text        TEXT NOT NULL,
  likes_count INT DEFAULT 0,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_comments_video ON comments(video_id, created_at DESC);

-- ══════════════════════════════════════
-- CHATS & MESSAGES
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS chat_rooms (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  type          VARCHAR(20) DEFAULT 'direct',
  name          VARCHAR(100),
  last_message  TEXT,
  last_message_at TIMESTAMPTZ,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS chat_participants (
  room_id    UUID REFERENCES chat_rooms(id) ON DELETE CASCADE,
  user_id    UUID REFERENCES users(id) ON DELETE CASCADE,
  unread_count INT DEFAULT 0,
  joined_at  TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (room_id, user_id)
);

CREATE TABLE IF NOT EXISTS messages (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  room_id     UUID REFERENCES chat_rooms(id) ON DELETE CASCADE,
  sender_id   UUID REFERENCES users(id) ON DELETE SET NULL,
  text        TEXT,
  media_url   TEXT,
  media_type  VARCHAR(20),
  is_read     BOOLEAN DEFAULT FALSE,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_messages_room ON messages(room_id, created_at DESC);

-- ══════════════════════════════════════
-- WALLET
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS wallets (
  id                 UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id            UUID UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  balance            DECIMAL(15,2) DEFAULT 0.00,
  total_earned       DECIMAL(15,2) DEFAULT 0.00,
  total_withdrawn    DECIMAL(15,2) DEFAULT 0.00,
  pending_withdrawal DECIMAL(15,2) DEFAULT 0.00,
  currency           VARCHAR(10) DEFAULT 'BDT',
  updated_at         TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS transactions (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID REFERENCES users(id) ON DELETE CASCADE,
  type        VARCHAR(30) NOT NULL,
  amount      DECIMAL(15,4) NOT NULL,
  description TEXT,
  reference   VARCHAR(100),
  status      VARCHAR(20) DEFAULT 'completed',
  meta        JSONB DEFAULT '{}',
  created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_tx_user ON transactions(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS withdrawals (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id        UUID REFERENCES users(id) ON DELETE CASCADE,
  amount         DECIMAL(15,2) NOT NULL,
  fee            DECIMAL(15,2) DEFAULT 0,
  net_amount     DECIMAL(15,2) NOT NULL,
  method         VARCHAR(30) NOT NULL,
  account_number VARCHAR(50) NOT NULL,
  status         VARCHAR(20) DEFAULT 'pending',
  tx_id          VARCHAR(100),
  processed_at   TIMESTAMPTZ,
  created_at     TIMESTAMPTZ DEFAULT NOW()
);

-- ══════════════════════════════════════
-- LIVE STREAMS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS live_streams (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID REFERENCES users(id) ON DELETE CASCADE,
  title         VARCHAR(300),
  stream_key    VARCHAR(100) UNIQUE,
  thumbnail_url TEXT,
  viewer_count  INT DEFAULT 0,
  peak_viewers  INT DEFAULT 0,
  earnings      DECIMAL(15,4) DEFAULT 0,
  gift_count    INT DEFAULT 0,
  status        VARCHAR(20) DEFAULT 'live',
  started_at    TIMESTAMPTZ DEFAULT NOW(),
  ended_at      TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_live_status ON live_streams(status, viewer_count DESC);

-- ══════════════════════════════════════
-- NOTIFICATIONS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS notifications (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID REFERENCES users(id) ON DELETE CASCADE,
  type        VARCHAR(30) NOT NULL,
  title       VARCHAR(200),
  body        TEXT,
  data        JSONB DEFAULT '{}',
  is_read     BOOLEAN DEFAULT FALSE,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id, created_at DESC);

-- ══════════════════════════════════════
-- VIDEO VIEWS (for revenue calculation)
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS video_views (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  video_id    UUID REFERENCES videos(id) ON DELETE CASCADE,
  viewer_id   UUID REFERENCES users(id) ON DELETE SET NULL,
  viewer_ip   INET,
  watch_seconds INT DEFAULT 0,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_views_video ON video_views(video_id, created_at DESC);

-- ══════════════════════════════════════
-- SAVED VIDEOS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS saved_videos (
  video_id   UUID REFERENCES videos(id) ON DELETE CASCADE,
  user_id    UUID REFERENCES users(id)  ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (video_id, user_id)
);

-- ══════════════════════════════════════
-- OTP CODES
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS otp_codes (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  phone      VARCHAR(20),
  email      VARCHAR(255),
  code       VARCHAR(10) NOT NULL,
  purpose    VARCHAR(30) DEFAULT 'login',
  used       BOOLEAN DEFAULT FALSE,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ══════════════════════════════════════
-- UPDATED_AT TRIGGER
-- ══════════════════════════════════════
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname='trg_users_updated') THEN
    CREATE TRIGGER trg_users_updated BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at();
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname='trg_videos_updated') THEN
    CREATE TRIGGER trg_videos_updated BEFORE UPDATE ON videos FOR EACH ROW EXECUTE FUNCTION update_updated_at();
  END IF;
END $$;
`;

async function migrate() {
  console.log('⏳ Database migration শুরু হচ্ছে...');
  try {
    await db.query(migrations);
    console.log('✅ সব টেবিল তৈরি হয়েছে!');
    process.exit(0);
  } catch (err) {
    console.error('❌ Migration ব্যর্থ:', err.message);
    process.exit(1);
  }
}
migrate();
