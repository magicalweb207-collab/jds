// config/redis.js — Redis Client

const { createClient } = require('redis');
const logger = require('../utils/logger');

const client = createClient({
  url: process.env.REDIS_URL,
  socket: {
    tls: process.env.REDIS_TLS === 'true',
    reconnectStrategy: (retries) => Math.min(retries * 100, 3000),
  },
});

client.on('error', (err) => logger.error('Redis Error:', err.message));
client.on('reconnecting', () => logger.warn('Redis: পুনরায় সংযোগ হচ্ছে...'));
client.on('ready', () => logger.info('✅ Redis প্রস্তুত'));

// Helpers
client.getJSON  = async (key) => { const v = await client.get(key); return v ? JSON.parse(v) : null; };
client.setJSON  = (key, val, ttl = 3600) => client.setEx(key, ttl, JSON.stringify(val));
client.delJSON  = (key) => client.del(key);
client.incrJSON = (key) => client.incr(key);

module.exports = client;
