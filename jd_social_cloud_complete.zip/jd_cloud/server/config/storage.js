// config/storage.js — File Upload (S3 / Local)

const multer   = require('multer');
const path     = require('path');
const { v4: uuidv4 } = require('uuid');

let videoStorage, imageStorage;

if (process.env.AWS_ACCESS_KEY) {
  // ── AWS S3 Storage ──
  const multerS3 = require('multer-s3');
  const { S3Client } = require('@aws-sdk/client-s3');

  const s3 = new S3Client({
    region: process.env.AWS_REGION,
    credentials: {
      accessKeyId: process.env.AWS_ACCESS_KEY,
      secretAccessKey: process.env.AWS_SECRET_KEY,
    },
  });

  videoStorage = multerS3({
    s3,
    bucket: process.env.AWS_BUCKET,
    acl: 'public-read',
    contentType: multerS3.AUTO_CONTENT_TYPE,
    key: (req, file, cb) => {
      cb(null, `videos/${uuidv4()}${path.extname(file.originalname)}`);
    },
  });

  imageStorage = multerS3({
    s3,
    bucket: process.env.AWS_BUCKET,
    acl: 'public-read',
    contentType: multerS3.AUTO_CONTENT_TYPE,
    key: (req, file, cb) => {
      cb(null, `images/${uuidv4()}${path.extname(file.originalname)}`);
    },
  });
} else {
  // ── Local Storage (development) ──
  const fs = require('fs');
  const uploadDir = path.join(__dirname, '../uploads');
  ['videos','images'].forEach(d => {
    const dir = path.join(uploadDir, d);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  });

  videoStorage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, path.join(uploadDir, 'videos')),
    filename: (req, file, cb) => cb(null, uuidv4() + path.extname(file.originalname)),
  });

  imageStorage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, path.join(uploadDir, 'images')),
    filename: (req, file, cb) => cb(null, uuidv4() + path.extname(file.originalname)),
  });
}

const videoFilter = (req, file, cb) => {
  const allowed = ['video/mp4', 'video/quicktime', 'video/avi', 'video/webm', 'video/x-msvideo'];
  allowed.includes(file.mimetype) ? cb(null, true) : cb(new Error('শুধু ভিডিও ফাইল আপলোড করুন।'), false);
};

const imageFilter = (req, file, cb) => {
  const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
  allowed.includes(file.mimetype) ? cb(null, true) : cb(new Error('শুধু ছবি আপলোড করুন।'), false);
};

const uploadVideo = multer({
  storage: videoStorage,
  limits: { fileSize: 500 * 1024 * 1024 }, // 500MB
  fileFilter: videoFilter,
});

const uploadImage = multer({
  storage: imageStorage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: imageFilter,
});

module.exports = { uploadVideo, uploadImage };
