// routes/feed.js
const router = require('express').Router();
const db     = require('../config/database');
const { optionalAuth } = require('../middleware/auth');

router.get('/trending-tags', async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT UNNEST(hashtags) as tag, COUNT(*) as count
       FROM videos WHERE status='active' AND created_at > NOW()-INTERVAL '7 days'
       GROUP BY tag ORDER BY count DESC LIMIT 20`
    );
    res.json({ success: true, tags: rows });
  } catch (err) {
    res.status(500).json({ error: 'লোড হয়নি।' });
  }
});

router.get('/stats', async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT
         (SELECT COUNT(*) FROM users) as total_users,
         (SELECT COUNT(*) FROM videos WHERE status='active') as total_videos,
         (SELECT COUNT(*) FROM live_streams WHERE status='live') as live_count,
         (SELECT COALESCE(SUM(total_earned),0) FROM wallets) as total_paid`
    );
    res.json({ success: true, stats: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'লোড হয়নি।' });
  }
});

module.exports = router;
