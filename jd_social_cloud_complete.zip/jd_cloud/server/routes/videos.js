// routes/videos.js — Video CRUD + Engagement

const router  = require('express').Router();
const db      = require('../config/database');
const redis   = require('../config/redis');
const { auth, optionalAuth } = require('../middleware/auth');
const { uploadVideo } = require('../config/storage');
const revenueService = require('../utils/revenue');
const logger  = require('../utils/logger');

// ── Get Feed (For You / Following / Trending) ─
router.get('/feed', optionalAuth, async (req, res) => {
  try {
    const { type = 'foryou', page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    // Try Redis cache
    const cacheKey = `feed:${type}:${page}`;
    const cached = await redis.getJSON(cacheKey);
    if (cached && type === 'foryou') return res.json(cached);

    let query, params;
    if (type === 'following' && req.user) {
      query = `
        SELECT v.*, u.name, u.username, u.avatar_url, u.verified,
               COALESCE(vl.liked, false) as is_liked,
               COALESCE(sv.saved, false) as is_saved
        FROM videos v
        JOIN users u ON u.id = v.user_id
        JOIN follows f ON f.following_id = v.user_id AND f.follower_id = $1
        LEFT JOIN LATERAL (SELECT true as liked FROM video_likes WHERE video_id=v.id AND user_id=$1) vl ON true
        LEFT JOIN LATERAL (SELECT true as saved FROM saved_videos WHERE video_id=v.id AND user_id=$1) sv ON true
        WHERE v.status = 'active' AND v.is_public = true
        ORDER BY v.created_at DESC
        LIMIT $2 OFFSET $3`;
      params = [req.user.id, limit, offset];
    } else if (type === 'trending') {
      query = `
        SELECT v.*, u.name, u.username, u.avatar_url, u.verified,
               false as is_liked, false as is_saved
        FROM videos v
        JOIN users u ON u.id = v.user_id
        WHERE v.status = 'active' AND v.is_public = true
          AND v.created_at > NOW() - INTERVAL '7 days'
        ORDER BY (v.views * 1 + v.likes_count * 5 + v.shares_count * 10) DESC
        LIMIT $1 OFFSET $2`;
      params = [limit, offset];
    } else {
      // For You — personalized (simplified algorithm)
      query = `
        SELECT v.*, u.name, u.username, u.avatar_url, u.verified,
               COALESCE(vl.liked, false) as is_liked,
               false as is_saved
        FROM videos v
        JOIN users u ON u.id = v.user_id
        LEFT JOIN LATERAL (
          SELECT true as liked FROM video_likes
          WHERE video_id=v.id AND user_id=$1
        ) vl ON true
        WHERE v.status = 'active' AND v.is_public = true
        ORDER BY (v.likes_count * 3 + v.views * 1 + v.comments_count * 5) DESC,
                 v.created_at DESC
        LIMIT $2 OFFSET $3`;
      params = [req.user?.id || null, limit, offset];
    }

    const { rows } = await db.query(query, params);
    const result = { success: true, videos: rows, page: +page, hasMore: rows.length === +limit };

    if (type === 'foryou') await redis.setJSON(cacheKey, result, 120);
    res.json(result);
  } catch (err) {
    logger.error('Feed error:', err.message);
    res.status(500).json({ error: 'ফিড লোড হয়নি।' });
  }
});

// ── Upload Video ──────────────────────────────
router.post('/', auth, uploadVideo.single('video'), async (req, res) => {
  try {
    const { title, description, hashtags, is_public = true } = req.body;
    if (!title) return res.status(400).json({ error: 'শিরোনাম আবশ্যক।' });
    if (!req.file) return res.status(400).json({ error: 'ভিডিও ফাইল আবশ্যক।' });

    const videoUrl = req.file.location || `/uploads/${req.file.filename}`;
    const tags = hashtags ? JSON.parse(hashtags) : [];

    const { rows } = await db.query(
      `INSERT INTO videos (user_id, title, description, video_url, hashtags, is_public, size_bytes)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [req.user.id, title, description || '', videoUrl, tags, is_public, req.file.size || 0]
    );

    await db.query('UPDATE users SET video_count = video_count + 1 WHERE id=$1', [req.user.id]);
    await redis.del(`feed:foryou:1`); // invalidate cache

    res.status(201).json({ success: true, video: rows[0] });
  } catch (err) {
    logger.error('Upload error:', err.message);
    res.status(500).json({ error: 'আপলোড ব্যর্থ।' });
  }
});

// ── Get Single Video ──────────────────────────
router.get('/:id', optionalAuth, async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT v.*, u.name, u.username, u.avatar_url, u.verified, u.followers_count,
              COALESCE(vl.liked, false) as is_liked
       FROM videos v JOIN users u ON u.id = v.user_id
       LEFT JOIN LATERAL (SELECT true as liked FROM video_likes WHERE video_id=v.id AND user_id=$2) vl ON true
       WHERE v.id=$1`,
      [req.params.id, req.user?.id || null]
    );
    if (!rows[0]) return res.status(404).json({ error: 'ভিডিও পাওয়া যায়নি।' });

    // Record view (async, non-blocking)
    db.query(
      'INSERT INTO video_views (video_id, viewer_id, viewer_ip) VALUES ($1,$2,$3)',
      [req.params.id, req.user?.id || null, req.ip]
    ).then(() => {
      db.query('UPDATE videos SET views = views + 1 WHERE id=$1', [req.params.id]);
      if (rows[0].user_id && req.user?.id !== rows[0].user_id) {
        revenueService.creditViewEarning(rows[0].user_id, req.params.id);
      }
    }).catch(() => {});

    res.json({ success: true, video: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'ভিডিও লোড হয়নি।' });
  }
});

// ── Like / Unlike ─────────────────────────────
router.post('/:id/like', auth, async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;
    const existing = await db.query(
      'SELECT 1 FROM video_likes WHERE video_id=$1 AND user_id=$2', [id, userId]
    );

    if (existing.rows.length > 0) {
      await db.query('DELETE FROM video_likes WHERE video_id=$1 AND user_id=$2', [id, userId]);
      await db.query('UPDATE videos SET likes_count = GREATEST(0, likes_count-1) WHERE id=$1', [id]);
      res.json({ success: true, liked: false });
    } else {
      await db.query('INSERT INTO video_likes (video_id, user_id) VALUES ($1,$2) ON CONFLICT DO NOTHING', [id, userId]);
      await db.query('UPDATE videos SET likes_count = likes_count+1 WHERE id=$1', [id]);
      res.json({ success: true, liked: true });
    }
  } catch (err) {
    res.status(500).json({ error: 'লাইক ব্যর্থ।' });
  }
});

// ── Comments ──────────────────────────────────
router.get('/:id/comments', async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const { rows } = await db.query(
      `SELECT c.*, u.name, u.username, u.avatar_url
       FROM comments c JOIN users u ON u.id = c.user_id
       WHERE c.video_id=$1 AND c.parent_id IS NULL
       ORDER BY c.created_at DESC LIMIT $2 OFFSET $3`,
      [req.params.id, limit, (page-1)*limit]
    );
    res.json({ success: true, comments: rows });
  } catch (err) {
    res.status(500).json({ error: 'কমেন্ট লোড হয়নি।' });
  }
});

router.post('/:id/comments', auth, async (req, res) => {
  try {
    const { text, parent_id } = req.body;
    if (!text?.trim()) return res.status(400).json({ error: 'কমেন্ট লিখুন।' });

    const { rows } = await db.query(
      `INSERT INTO comments (video_id, user_id, text, parent_id) VALUES ($1,$2,$3,$4)
       RETURNING *, (SELECT name FROM users WHERE id=$2) as name, (SELECT username FROM users WHERE id=$2) as username`,
      [req.params.id, req.user.id, text.trim(), parent_id || null]
    );
    await db.query('UPDATE videos SET comments_count = comments_count+1 WHERE id=$1', [req.params.id]);
    res.status(201).json({ success: true, comment: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'কমেন্ট যোগ ব্যর্থ।' });
  }
});

// ── Save / Unsave ─────────────────────────────
router.post('/:id/save', auth, async (req, res) => {
  try {
    const existing = await db.query(
      'SELECT 1 FROM saved_videos WHERE video_id=$1 AND user_id=$2', [req.params.id, req.user.id]
    );
    if (existing.rows.length > 0) {
      await db.query('DELETE FROM saved_videos WHERE video_id=$1 AND user_id=$2', [req.params.id, req.user.id]);
      res.json({ success: true, saved: false });
    } else {
      await db.query('INSERT INTO saved_videos VALUES ($1,$2) ON CONFLICT DO NOTHING', [req.params.id, req.user.id]);
      res.json({ success: true, saved: true });
    }
  } catch (err) {
    res.status(500).json({ error: 'সেভ ব্যর্থ।' });
  }
});

// ── Search ────────────────────────────────────
router.get('/search/query', async (req, res) => {
  try {
    const { q, page = 1, limit = 20 } = req.query;
    if (!q) return res.json({ success: true, videos: [] });

    const { rows } = await db.query(
      `SELECT v.*, u.name, u.username, u.avatar_url
       FROM videos v JOIN users u ON u.id = v.user_id
       WHERE v.status='active' AND v.is_public=true
         AND (v.title ILIKE $1 OR $2=ANY(v.hashtags))
       ORDER BY v.views DESC LIMIT $3 OFFSET $4`,
      [`%${q}%`, q.replace('#',''), limit, (page-1)*limit]
    );
    res.json({ success: true, videos: rows });
  } catch (err) {
    res.status(500).json({ error: 'সার্চ ব্যর্থ।' });
  }
});

// ── Delete Video ──────────────────────────────
router.delete('/:id', auth, async (req, res) => {
  try {
    const { rows } = await db.query('SELECT user_id FROM videos WHERE id=$1', [req.params.id]);
    if (!rows[0]) return res.status(404).json({ error: 'ভিডিও পাওয়া যায়নি।' });
    if (rows[0].user_id !== req.user.id && !req.user.is_admin) {
      return res.status(403).json({ error: 'অনুমতি নেই।' });
    }
    await db.query('UPDATE videos SET status=$1 WHERE id=$2', ['deleted', req.params.id]);
    await db.query('UPDATE users SET video_count=GREATEST(0,video_count-1) WHERE id=$1', [req.user.id]);
    res.json({ success: true, message: 'ভিডিও মুছে ফেলা হয়েছে।' });
  } catch (err) {
    res.status(500).json({ error: 'ডিলিট ব্যর্থ।' });
  }
});

module.exports = router;
