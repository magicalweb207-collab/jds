// routes/admin.js — Admin Dashboard API

const router = require('express').Router();
const db     = require('../config/database');
const redis  = require('../config/redis');
const { adminAuth } = require('../middleware/auth');

// Dashboard stats
router.get('/stats', adminAuth, async (req, res) => {
  try {
    const { rows } = await db.query(`
      SELECT
        (SELECT COUNT(*) FROM users) as total_users,
        (SELECT COUNT(*) FROM users WHERE created_at > NOW()-INTERVAL '24h') as new_users_today,
        (SELECT COUNT(*) FROM videos WHERE status='active') as total_videos,
        (SELECT COUNT(*) FROM live_streams WHERE status='live') as live_now,
        (SELECT COALESCE(SUM(total_earned),0) FROM wallets) as total_revenue_paid,
        (SELECT COALESCE(SUM(amount),0) FROM withdrawals WHERE status='pending') as pending_withdrawals,
        (SELECT COUNT(*) FROM withdrawals WHERE status='pending') as pending_withdrawal_count
    `);
    res.json({ success: true, stats: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'লোড হয়নি।' });
  }
});

// Top creators
router.get('/top-creators', adminAuth, async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT u.id, u.name, u.username, u.avatar_url, u.video_count, u.followers_count,
              w.balance, w.total_earned
       FROM users u JOIN wallets w ON w.user_id=u.id
       ORDER BY w.total_earned DESC LIMIT 20`
    );
    res.json({ success: true, creators: rows });
  } catch (err) {
    res.status(500).json({ error: 'লোড হয়নি।' });
  }
});

// Pending withdrawals
router.get('/withdrawals/pending', adminAuth, async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT wd.*, u.name, u.username, u.phone
       FROM withdrawals wd JOIN users u ON u.id=wd.user_id
       WHERE wd.status='pending'
       ORDER BY wd.created_at ASC`
    );
    res.json({ success: true, withdrawals: rows });
  } catch (err) {
    res.status(500).json({ error: 'লোড হয়নি।' });
  }
});

// Approve withdrawal
router.put('/withdrawals/:id/approve', adminAuth, async (req, res) => {
  try {
    const { rows } = await db.query(
      `UPDATE withdrawals SET status='completed', processed_at=NOW()
       WHERE id=$1 AND status='pending' RETURNING *`,
      [req.params.id]
    );
    if (!rows[0]) return res.status(404).json({ error: 'পাওয়া যায়নি।' });
    await db.query(
      'UPDATE wallets SET pending_withdrawal=GREATEST(0,pending_withdrawal-$1), total_withdrawn=total_withdrawn+$1 WHERE user_id=$2',
      [rows[0].amount, rows[0].user_id]
    );
    await redis.del(`wallet:${rows[0].user_id}`);
    res.json({ success: true, withdrawal: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'অনুমোদন ব্যর্থ।' });
  }
});

// Ban / Unban user
router.put('/users/:id/ban', adminAuth, async (req, res) => {
  try {
    const { rows } = await db.query(
      'UPDATE users SET is_banned=NOT is_banned WHERE id=$1 RETURNING id, name, is_banned',
      [req.params.id]
    );
    await redis.del(`user:${req.params.id}`);
    res.json({ success: true, user: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'আপডেট ব্যর্থ।' });
  }
});

// Delete video
router.delete('/videos/:id', adminAuth, async (req, res) => {
  try {
    await db.query("UPDATE videos SET status='deleted' WHERE id=$1", [req.params.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'ডিলিট ব্যর্থ।' });
  }
});

// Revenue report (last 30 days)
router.get('/revenue/report', adminAuth, async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT DATE(created_at) as date, type, SUM(amount) as total
       FROM transactions WHERE created_at > NOW()-INTERVAL '30 days' AND amount > 0
       GROUP BY DATE(created_at), type ORDER BY date DESC`
    );
    res.json({ success: true, report: rows });
  } catch (err) {
    res.status(500).json({ error: 'রিপোর্ট লোড হয়নি।' });
  }
});

module.exports = router;
