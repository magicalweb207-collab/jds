// routes/chat.js — Chat Rooms & Messages

const router = require('express').Router();
const db     = require('../config/database');
const redis  = require('../config/redis');
const { auth } = require('../middleware/auth');
const logger = require('../utils/logger');

// ── Get all chat rooms for current user ──
router.get('/rooms', auth, async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT cr.*, cp.unread_count,
              u.name as other_name, u.username as other_username,
              u.avatar_url as other_avatar, u.id as other_id,
              CASE WHEN ou.last_seen > NOW()-INTERVAL '5 min' THEN true ELSE false END as is_online
       FROM chat_rooms cr
       JOIN chat_participants cp ON cp.room_id = cr.id AND cp.user_id = $1
       JOIN chat_participants cp2 ON cp2.room_id = cr.id AND cp2.user_id != $1
       JOIN users u ON u.id = cp2.user_id
       LEFT JOIN users ou ON ou.id = cp2.user_id
       WHERE cr.type = 'direct'
       ORDER BY cr.last_message_at DESC NULLS LAST`,
      [req.user.id]
    );
    res.json({ success: true, rooms: rows });
  } catch (err) {
    logger.error('Get rooms error:', err.message);
    res.status(500).json({ error: 'চ্যাট লোড হয়নি।' });
  }
});

// ── Create or get direct chat room ──
router.post('/rooms', auth, async (req, res) => {
  try {
    const { userId } = req.body;
    if (!userId) return res.status(400).json({ error: 'userId আবশ্যক।' });
    if (userId === req.user.id) return res.status(400).json({ error: 'নিজের সাথে চ্যাট করা যাবে না।' });

    // Check if room already exists
    const { rows: existing } = await db.query(
      `SELECT cr.id FROM chat_rooms cr
       JOIN chat_participants cp1 ON cp1.room_id = cr.id AND cp1.user_id = $1
       JOIN chat_participants cp2 ON cp2.room_id = cr.id AND cp2.user_id = $2
       WHERE cr.type = 'direct' LIMIT 1`,
      [req.user.id, userId]
    );

    if (existing.length > 0) {
      return res.json({ success: true, roomId: existing[0].id, existing: true });
    }

    const result = await db.transaction(async (client) => {
      const { rows } = await client.query(
        `INSERT INTO chat_rooms (type) VALUES ('direct') RETURNING id`
      );
      const roomId = rows[0].id;
      await client.query(
        `INSERT INTO chat_participants (room_id, user_id) VALUES ($1,$2),($1,$3)`,
        [roomId, req.user.id, userId]
      );
      return roomId;
    });

    res.status(201).json({ success: true, roomId: result, existing: false });
  } catch (err) {
    logger.error('Create room error:', err.message);
    res.status(500).json({ error: 'চ্যাট তৈরি হয়নি।' });
  }
});

// ── Get messages in a room ──
router.get('/:roomId/messages', auth, async (req, res) => {
  try {
    const { page = 1, limit = 30 } = req.query;

    // Verify participant
    const { rows: check } = await db.query(
      'SELECT 1 FROM chat_participants WHERE room_id=$1 AND user_id=$2',
      [req.params.roomId, req.user.id]
    );
    if (!check.length) return res.status(403).json({ error: 'অ্যাক্সেস নেই।' });

    const { rows } = await db.query(
      `SELECT m.*, u.name as sender_name, u.username as sender_username, u.avatar_url as sender_avatar
       FROM messages m
       LEFT JOIN users u ON u.id = m.sender_id
       WHERE m.room_id = $1
       ORDER BY m.created_at DESC
       LIMIT $2 OFFSET $3`,
      [req.params.roomId, limit, (page - 1) * limit]
    );

    // Mark as read
    await db.query(
      'UPDATE messages SET is_read=true WHERE room_id=$1 AND sender_id!=$2 AND is_read=false',
      [req.params.roomId, req.user.id]
    );
    await db.query(
      'UPDATE chat_participants SET unread_count=0 WHERE room_id=$1 AND user_id=$2',
      [req.params.roomId, req.user.id]
    );

    res.json({ success: true, messages: rows.reverse(), hasMore: rows.length === +limit });
  } catch (err) {
    res.status(500).json({ error: 'মেসেজ লোড হয়নি।' });
  }
});

// ── Send message via REST (fallback if socket fails) ──
router.post('/:roomId/messages', auth, async (req, res) => {
  try {
    const { text, mediaUrl, mediaType } = req.body;
    if (!text?.trim() && !mediaUrl) return res.status(400).json({ error: 'মেসেজ লিখুন।' });

    const { rows: check } = await db.query(
      'SELECT 1 FROM chat_participants WHERE room_id=$1 AND user_id=$2',
      [req.params.roomId, req.user.id]
    );
    if (!check.length) return res.status(403).json({ error: 'অ্যাক্সেস নেই।' });

    const { rows } = await db.query(
      `INSERT INTO messages (room_id, sender_id, text, media_url, media_type)
       VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [req.params.roomId, req.user.id, text?.trim() || null, mediaUrl || null, mediaType || null]
    );

    await db.query(
      'UPDATE chat_rooms SET last_message=$1, last_message_at=NOW() WHERE id=$2',
      [text?.substring(0, 100), req.params.roomId]
    );

    res.status(201).json({ success: true, message: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'মেসেজ পাঠানো যায়নি।' });
  }
});

module.exports = router;
