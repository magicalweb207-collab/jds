// routes/auth.js — Authentication Routes

const router   = require('express').Router();
const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const db       = require('../config/database');
const redis    = require('../config/redis');
const { auth } = require('../middleware/auth');
const logger   = require('../utils/logger');
const { sendSMS, sendEmail } = require('../utils/notifications');

const genToken = (userId, expires = process.env.JWT_EXPIRE || '7d') =>
  jwt.sign({ id: userId }, process.env.JWT_SECRET, { expiresIn: expires });

const genRefreshToken = (userId) =>
  jwt.sign({ id: userId, type: 'refresh' }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRE || '30d',
  });

// ── Register ──────────────────────────────────
router.post('/register', async (req, res) => {
  try {
    const { name, username, email, phone, password } = req.body;
    if (!name || !username) return res.status(400).json({ error: 'নাম ও ইউজারনেম আবশ্যক।' });

    const existing = await db.query(
      'SELECT id FROM users WHERE username=$1 OR email=$2 OR phone=$3',
      [username, email || null, phone || null]
    );
    if (existing.rows.length > 0) {
      return res.status(400).json({ error: 'ইউজারনেম বা ইমেইল আগেই নিবন্ধিত।' });
    }

    const hash = password ? await bcrypt.hash(password, 12) : null;
    const { rows } = await db.query(
      `INSERT INTO users (name, username, email, phone, password_hash)
       VALUES ($1,$2,$3,$4,$5) RETURNING id, name, username, email, phone, avatar_url`,
      [name, username.toLowerCase(), email || null, phone || null, hash]
    );

    // Create wallet
    await db.query('INSERT INTO wallets (user_id) VALUES ($1) ON CONFLICT DO NOTHING', [rows[0].id]);

    const token        = genToken(rows[0].id);
    const refreshToken = genRefreshToken(rows[0].id);
    await redis.setEx(`refresh:${rows[0].id}`, 30 * 24 * 3600, refreshToken);

    res.cookie('token', token, { httpOnly: true, secure: true, sameSite: 'none', maxAge: 7 * 86400000 });
    res.status(201).json({ success: true, token, refreshToken, user: rows[0] });
  } catch (err) {
    logger.error('Register error:', err.message);
    res.status(500).json({ error: 'নিবন্ধন ব্যর্থ হয়েছে।' });
  }
});

// ── Login ─────────────────────────────────────
router.post('/login', async (req, res) => {
  try {
    const { identifier, password } = req.body;
    if (!identifier || !password) return res.status(400).json({ error: 'সব তথ্য দিন।' });

    const { rows } = await db.query(
      `SELECT id, name, username, email, phone, password_hash, avatar_url, is_banned, verified
       FROM users WHERE email=$1 OR username=$1 OR phone=$1`,
      [identifier]
    );
    if (!rows[0]) return res.status(400).json({ error: 'ব্যবহারকারী পাওয়া যায়নি।' });
    if (rows[0].is_banned) return res.status(403).json({ error: 'অ্যাকাউন্ট নিষিদ্ধ।' });

    const valid = rows[0].password_hash && await bcrypt.compare(password, rows[0].password_hash);
    if (!valid) return res.status(400).json({ error: 'পাসওয়ার্ড ভুল।' });

    await db.query('UPDATE users SET last_seen=NOW() WHERE id=$1', [rows[0].id]);
    const token = genToken(rows[0].id);
    const refreshToken = genRefreshToken(rows[0].id);
    await redis.setEx(`refresh:${rows[0].id}`, 30 * 24 * 3600, refreshToken);

    res.cookie('token', token, { httpOnly: true, secure: true, sameSite: 'none', maxAge: 7 * 86400000 });
    const { password_hash, ...user } = rows[0];
    res.json({ success: true, token, refreshToken, user });
  } catch (err) {
    logger.error('Login error:', err.message);
    res.status(500).json({ error: 'লগইন ব্যর্থ হয়েছে।' });
  }
});

// ── Send OTP ─────────────────────────────────
router.post('/send-otp', async (req, res) => {
  try {
    const { phone } = req.body;
    if (!phone) return res.status(400).json({ error: 'ফোন নম্বর দিন।' });

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

    await db.query(
      `INSERT INTO otp_codes (phone, code, purpose, expires_at)
       VALUES ($1, $2, 'login', $3)`,
      [phone, code, expiresAt]
    );

    // Cache in Redis for fast lookup
    await redis.setEx(`otp:${phone}`, 600, code);

    // Send SMS (uncomment when Twilio configured)
    // await sendSMS(phone, `আপনার JD Social OTP: ${code}. ১০ মিনিটের মধ্যে ব্যবহার করুন।`);

    // Dev mode: return code in response
    const isDev = process.env.NODE_ENV !== 'production';
    res.json({ success: true, message: 'OTP পাঠানো হয়েছে।', ...(isDev && { code }) });
  } catch (err) {
    res.status(500).json({ error: 'OTP পাঠানো যায়নি।' });
  }
});

// ── Verify OTP ───────────────────────────────
router.post('/verify-otp', async (req, res) => {
  try {
    const { phone, code, name } = req.body;
    const cachedCode = await redis.get(`otp:${phone}`);

    if (!cachedCode || cachedCode !== code) {
      return res.status(400).json({ error: 'OTP ভুল বা মেয়াদোত্তীর্ণ।' });
    }

    await redis.del(`otp:${phone}`);

    let { rows } = await db.query('SELECT * FROM users WHERE phone=$1', [phone]);
    let user = rows[0];

    if (!user) {
      const username = 'user_' + phone.slice(-6) + '_' + Math.random().toString(36).slice(2,5);
      const { rows: newRows } = await db.query(
        `INSERT INTO users (name, username, phone) VALUES ($1,$2,$3)
         RETURNING id, name, username, phone, avatar_url`,
        [name || 'JD ব্যবহারকারী', username, phone]
      );
      user = newRows[0];
      await db.query('INSERT INTO wallets (user_id) VALUES ($1)', [user.id]);
    }

    const token = genToken(user.id);
    const refreshToken = genRefreshToken(user.id);
    await redis.setEx(`refresh:${user.id}`, 30 * 24 * 3600, refreshToken);

    res.cookie('token', token, { httpOnly: true, secure: true, sameSite: 'none' });
    res.json({ success: true, token, refreshToken, user });
  } catch (err) {
    logger.error('OTP verify error:', err.message);
    res.status(500).json({ error: 'যাচাই ব্যর্থ।' });
  }
});

// ── Refresh Token ─────────────────────────────
router.post('/refresh', async (req, res) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) return res.status(401).json({ error: 'Refresh token নেই।' });

    const decoded = jwt.verify(refreshToken, process.env.JWT_SECRET);
    const stored  = await redis.get(`refresh:${decoded.id}`);
    if (stored !== refreshToken) return res.status(401).json({ error: 'অবৈধ refresh token।' });

    const newToken = genToken(decoded.id);
    res.json({ success: true, token: newToken });
  } catch (err) {
    res.status(401).json({ error: 'Token refresh ব্যর্থ।' });
  }
});

// ── Logout ───────────────────────────────────
router.post('/logout', auth, async (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1] || req.cookies?.token;
    if (token) await redis.setEx(`blacklist:${token}`, 7 * 86400, '1');
    await redis.del(`refresh:${req.user.id}`);
    await redis.del(`user:${req.user.id}`);
    res.clearCookie('token');
    res.json({ success: true, message: 'লগআউট সফল।' });
  } catch (err) {
    res.status(500).json({ error: 'লগআউট ব্যর্থ।' });
  }
});

// ── Get Current User ─────────────────────────
router.get('/me', auth, async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT u.*, w.balance, w.total_earned
       FROM users u LEFT JOIN wallets w ON w.user_id = u.id
       WHERE u.id=$1`,
      [req.user.id]
    );
    const { password_hash, ...user } = rows[0];
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ error: 'তথ্য লোড হয়নি।' });
  }
});

module.exports = router;
