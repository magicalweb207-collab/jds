// routes/upload.js — File Upload Routes
const router = require('express').Router();
const { auth } = require('../middleware/auth');
const { uploadImage, uploadVideo } = require('../config/storage');

router.post('/avatar', auth, uploadImage.single('avatar'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'ছবি আবশ্যক।' });
  const url = req.file.location || `/uploads/images/${req.file.filename}`;
  res.json({ success: true, url });
});

router.post('/video', auth, uploadVideo.single('video'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'ভিডিও আবশ্যক।' });
  const url = req.file.location || `/uploads/videos/${req.file.filename}`;
  res.json({ success: true, url, size: req.file.size });
});

module.exports = router;

// ════════════════════════════════════════════════════════
// routes/payment.js — Payment Webhook Handler
// ════════════════════════════════════════════════════════
const payRouter = require('express').Router();
const db = require('../config/database');
const logger = require('../utils/logger');

// bKash payment callback
payRouter.post('/bkash/callback', async (req, res) => {
  try {
    const { paymentID, status } = req.body;
    logger.info(`bKash callback: ${paymentID} — ${status}`);
    if (status === 'Completed') {
      await db.query(
        `UPDATE withdrawals SET status='completed', processed_at=NOW() WHERE tx_id=$1`,
        [paymentID]
      );
    }
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Webhook error.' });
  }
});

// Nagad callback
payRouter.post('/nagad/callback', async (req, res) => {
  try {
    const { merchantOrderId, status } = req.body;
    if (status === 'SUCCESS') {
      await db.query(
        `UPDATE withdrawals SET status='completed', processed_at=NOW() WHERE tx_id=$1`,
        [merchantOrderId]
      );
    }
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Webhook error.' });
  }
});

module.exports = payRouter;
