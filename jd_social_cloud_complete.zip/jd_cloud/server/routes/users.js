// routes/users.js
const router = require('express').Router();
const bcrypt = require('bcryptjs');
const db     = require('../config/database');
const redis  = require('../config/redis');
const { auth, optionalAuth } = require('../middleware/auth');
const { uploadImage } = require('../config/storage');

// Get user profile
router.get('/:username', optionalAuth, async (req, res) => {
  try {
    const cacheKey = `profile:${req.params.username}`;
    let profile = await redis.getJSON(cacheKey);
    if (!profile) {
      const { rows } = await db.query(
        `SELECT u.id, u.name, u.username, u.bio, u.avatar_url, u.cover_url,
                u.verified, u.followers_count, u.following_count, u.video_count,
                u.total_likes, u.created_at,
                CASE WHEN f.follower_id IS NOT NULL THEN true ELSE false END as is_followed
         FROM users u
         LEFT JOIN follows f ON f.following_id=u.id AND f.follower_id=$2
         WHERE u.username=$1`,
        [req.params.username, req.user?.id || null]
      );
      if (!rows[0]) return res.status(404).json({ error: 'ব্যবহারকারী পাওয়া যায়নি।' });
      profile = rows[0];
      await redis.setJSON(cacheKey, profile, 300);
    }
    res.json({ success: true, user: profile });
  } catch (err) {
    res.status(500).json({ error: 'প্রোফাইল লোড হয়নি।' });
  }
});

// Update profile
router.put('/me/profile', auth, uploadImage.single('avatar'), async (req, res) => {
  try {
    const { name, bio, username } = req.body;
    const avatarUrl = req.file?.location || req.file ? `/uploads/images/${req.file?.filename}` : undefined;
    const updates = [];
    const values = [];
    let idx = 1;
    if (name)      { updates.push(`name=$${idx++}`);       values.push(name); }
    if (bio !== undefined) { updates.push(`bio=$${idx++}`); values.push(bio); }
    if (username)  { updates.push(`username=$${idx++}`);   values.push(username.toLowerCase()); }
    if (avatarUrl) { updates.push(`avatar_url=$${idx++}`); values.push(avatarUrl); }
    if (!updates.length) return res.status(400).json({ error: 'কোনো পরিবর্তন নেই।' });
    values.push(req.user.id);
    const { rows } = await db.query(
      `UPDATE users SET ${updates.join(',')} WHERE id=$${idx} RETURNING id,name,username,bio,avatar_url`,
      values
    );
    await redis.del(`user:${req.user.id}`);
    await redis.del(`profile:${req.user.username}`);
    res.json({ success: true, user: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'আপডেট ব্যর্থ।' });
  }
});

// Follow / Unfollow
router.post('/:userId/follow', auth, async (req, res) => {
  try {
    const { userId } = req.params;
    if (userId === req.user.id) return res.status(400).json({ error: 'নিজেকে ফলো করা যাবে না।' });
    const existing = await db.query(
      'SELECT 1 FROM follows WHERE follower_id=$1 AND following_id=$2', [req.user.id, userId]
    );
    if (existing.rows.length > 0) {
      await db.query('DELETE FROM follows WHERE follower_id=$1 AND following_id=$2', [req.user.id, userId]);
      await db.query('UPDATE users SET followers_count=GREATEST(0,followers_count-1) WHERE id=$1', [userId]);
      await db.query('UPDATE users SET following_count=GREATEST(0,following_count-1) WHERE id=$1', [req.user.id]);
      res.json({ success: true, following: false });
    } else {
      await db.query('INSERT INTO follows VALUES ($1,$2) ON CONFLICT DO NOTHING', [req.user.id, userId]);
      await db.query('UPDATE users SET followers_count=followers_count+1 WHERE id=$1', [userId]);
      await db.query('UPDATE users SET following_count=following_count+1 WHERE id=$1', [req.user.id]);
      res.json({ success: true, following: true });
    }
    await redis.del(`profile:${userId}`);
  } catch (err) {
    res.status(500).json({ error: 'ফলো ব্যর্থ।' });
  }
});

// Search users
router.get('/search/query', async (req, res) => {
  try {
    const { q } = req.query;
    if (!q) return res.json({ success: true, users: [] });
    const { rows } = await db.query(
      `SELECT id, name, username, avatar_url, verified, followers_count
       FROM users WHERE username ILIKE $1 OR name ILIKE $1 LIMIT 20`,
      [`%${q}%`]
    );
    res.json({ success: true, users: rows });
  } catch (err) {
    res.status(500).json({ error: 'সার্চ ব্যর্থ।' });
  }
});

// Change password
router.put('/me/password', auth, async (req, res) => {
  try {
    const { current, newPass } = req.body;
    const { rows } = await db.query('SELECT password_hash FROM users WHERE id=$1', [req.user.id]);
    if (rows[0]?.password_hash) {
      const valid = await bcrypt.compare(current, rows[0].password_hash);
      if (!valid) return res.status(400).json({ error: 'বর্তমান পাসওয়ার্ড ভুল।' });
    }
    const hash = await bcrypt.hash(newPass, 12);
    await db.query('UPDATE users SET password_hash=$1 WHERE id=$2', [hash, req.user.id]);
    res.json({ success: true, message: 'পাসওয়ার্ড পরিবর্তন হয়েছে।' });
  } catch (err) {
    res.status(500).json({ error: 'পরিবর্তন ব্যর্থ।' });
  }
});

module.exports = router;
