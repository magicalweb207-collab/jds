// routes/wallet.js — Wallet & Withdrawal

const router = require('express').Router();
const db     = require('../config/database');
const redis  = require('../config/redis');
const { auth } = require('../middleware/auth');
const logger = require('../utils/logger');
const axios  = require('axios');
const { v4: uuidv4 } = require('uuid');

// ── Get Wallet Balance ────────────────────────
router.get('/', auth, async (req, res) => {
  try {
    let wallet = await redis.getJSON(`wallet:${req.user.id}`);
    if (!wallet) {
      const { rows } = await db.query(
        `SELECT w.*, 
                COALESCE((SELECT SUM(amount) FROM transactions WHERE user_id=$1 AND type='video_view' AND created_at > NOW()-INTERVAL '30 days'), 0) as month_views,
                COALESCE((SELECT SUM(amount) FROM transactions WHERE user_id=$1 AND type='ad_share' AND created_at > NOW()-INTERVAL '30 days'), 0) as month_ads,
                COALESCE((SELECT COUNT(*) FROM withdrawals WHERE user_id=$1 AND status='completed'), 0) as total_withdrawals
         FROM wallets w WHERE w.user_id=$1`,
        [req.user.id]
      );
      wallet = rows[0] || { balance: 0, total_earned: 0 };
      await redis.setJSON(`wallet:${req.user.id}`, wallet, 60);
    }

    // Recent transactions
    const { rows: txRows } = await db.query(
      'SELECT * FROM transactions WHERE user_id=$1 ORDER BY created_at DESC LIMIT 20',
      [req.user.id]
    );

    res.json({ success: true, wallet, transactions: txRows });
  } catch (err) {
    logger.error('Wallet error:', err.message);
    res.status(500).json({ error: 'ওয়ালেট লোড হয়নি।' });
  }
});

// ── Withdrawal Request ────────────────────────
router.post('/withdraw', auth, async (req, res) => {
  try {
    const { amount, method, account_number } = req.body;
    const MIN = parseFloat(process.env.MIN_WITHDRAWAL || 100);

    if (!amount || amount < MIN) return res.status(400).json({ error: `সর্বনিম্ন ৳${MIN} উত্তোলন করুন।` });
    if (!method || !account_number) return res.status(400).json({ error: 'পেমেন্ট তথ্য দিন।' });

    const result = await db.transaction(async (client) => {
      const { rows } = await client.query(
        'SELECT balance FROM wallets WHERE user_id=$1 FOR UPDATE', [req.user.id]
      );
      if (!rows[0] || rows[0].balance < amount) {
        throw new Error('অপর্যাপ্ত ব্যালেন্স।');
      }

      const fee = +(amount * 0.015).toFixed(2);
      const net = +(amount - fee).toFixed(2);
      const txId = 'JD' + Date.now().toString(36).toUpperCase();

      await client.query(
        'UPDATE wallets SET balance=balance-$1, pending_withdrawal=pending_withdrawal+$1 WHERE user_id=$2',
        [amount, req.user.id]
      );

      const { rows: wd } = await client.query(
        `INSERT INTO withdrawals (user_id, amount, fee, net_amount, method, account_number, status, tx_id)
         VALUES ($1,$2,$3,$4,$5,$6,'pending',$7) RETURNING *`,
        [req.user.id, amount, fee, net, method, account_number, txId]
      );

      await client.query(
        `INSERT INTO transactions (user_id, type, amount, description, reference, status)
         VALUES ($1,'withdrawal',$2,$3,$4,'pending')`,
        [req.user.id, -amount, `${method} উত্তোলন — ${account_number}`, txId]
      );

      return wd[0];
    });

    await redis.del(`wallet:${req.user.id}`);

    // Process payment based on method
    let paymentResult = null;
    if (method === 'bkash') {
      paymentResult = await processBkash(result, account_number, req);
    } else if (method === 'nagad') {
      paymentResult = await processNagad(result, account_number);
    }

    if (paymentResult?.success) {
      await db.query(
        `UPDATE withdrawals SET status='completed', processed_at=NOW()
         WHERE id=$1`, [result.id]
      );
      await db.query(
        'UPDATE wallets SET pending_withdrawal=pending_withdrawal-$1, total_withdrawn=total_withdrawn+$1 WHERE user_id=$2',
        [result.amount, req.user.id]
      );
    }

    res.json({
      success: true,
      message: 'উত্তোলন সফল! ৩-৫ মিনিটের মধ্যে পাবেন।',
      withdrawal: result,
      tx_id: result.tx_id,
    });
  } catch (err) {
    logger.error('Withdrawal error:', err.message);
    res.status(400).json({ error: err.message || 'উত্তোলন ব্যর্থ।' });
  }
});

// ── bKash Payment Processor ───────────────────
async function processBkash(withdrawal, phone, req) {
  try {
    if (!process.env.BKASH_APP_KEY) return { success: false, reason: 'bKash not configured' };

    // Step 1: Get token
    const tokenRes = await axios.post(
      `${process.env.BKASH_BASE_URL}/tokenized/checkout/token/grant`,
      { app_key: process.env.BKASH_APP_KEY, app_secret: process.env.BKASH_APP_SECRET },
      { headers: { username: process.env.BKASH_USERNAME, password: process.env.BKASH_PASSWORD } }
    );
    const token = tokenRes.data.id_token;

    // Step 2: Create disbursement
    const disbRes = await axios.post(
      `${process.env.BKASH_BASE_URL}/tokenized/checkout/disbursement`,
      {
        amount: withdrawal.net_amount.toString(),
        currency: 'BDT',
        intent: 'disbursement',
        merchantInvoiceNumber: withdrawal.tx_id,
        receiver_msisdn: phone,
      },
      { headers: { Authorization: token, 'X-APP-Key': process.env.BKASH_APP_KEY } }
    );

    return { success: disbRes.data.transactionStatus === 'Completed', data: disbRes.data };
  } catch (err) {
    logger.error('bKash error:', err.message);
    return { success: false };
  }
}

// ── Nagad Payment Processor ───────────────────
async function processNagad(withdrawal, phone) {
  try {
    if (!process.env.NAGAD_MERCHANT_ID) return { success: false };
    // Nagad B2C disbursement API
    const res = await axios.post(
      `${process.env.NAGAD_BASE_URL}/api/b2c-transfer`,
      {
        merchant_id: process.env.NAGAD_MERCHANT_ID,
        reference: withdrawal.tx_id,
        mobile: phone,
        amount: withdrawal.net_amount,
        currency: 'BDT',
      },
      { headers: { 'X-Api-Key': process.env.NAGAD_API_KEY } }
    );
    return { success: res.data.status === 'SUCCESS' };
  } catch (err) {
    logger.error('Nagad error:', err.message);
    return { success: false };
  }
}

// ── Withdrawal History ────────────────────────
router.get('/withdrawals', auth, async (req, res) => {
  try {
    const { rows } = await db.query(
      'SELECT * FROM withdrawals WHERE user_id=$1 ORDER BY created_at DESC LIMIT 50',
      [req.user.id]
    );
    res.json({ success: true, withdrawals: rows });
  } catch (err) {
    res.status(500).json({ error: 'লোড হয়নি।' });
  }
});

// ── Stats ─────────────────────────────────────
router.get('/stats', auth, async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT
         COALESCE(SUM(CASE WHEN type='video_view' THEN amount END), 0) as view_earnings,
         COALESCE(SUM(CASE WHEN type='ad_share' THEN amount END), 0) as ad_earnings,
         COALESCE(SUM(CASE WHEN type='live_gift' THEN amount END), 0) as gift_earnings,
         COALESCE(SUM(CASE WHEN type='referral' THEN amount END), 0) as referral_earnings,
         COUNT(*) as total_transactions
       FROM transactions WHERE user_id=$1 AND amount > 0`,
      [req.user.id]
    );
    res.json({ success: true, stats: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'স্ট্যাটস লোড হয়নি।' });
  }
});

module.exports = router;
