// routes/notifications.js
const router = require('express').Router();
const db     = require('../config/database');
const { auth } = require('../middleware/auth');

router.get('/', auth, async (req, res) => {
  try {
    const { rows } = await db.query(
      'SELECT * FROM notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT 50',
      [req.user.id]
    );
    const unread = rows.filter(n => !n.is_read).length;
    res.json({ success: true, notifications: rows, unread });
  } catch (err) {
    res.status(500).json({ error: 'লোড হয়নি।' });
  }
});

router.put('/read-all', auth, async (req, res) => {
  try {
    await db.query('UPDATE notifications SET is_read=true WHERE user_id=$1', [req.user.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'আপডেট ব্যর্থ।' });
  }
});

module.exports = router;
