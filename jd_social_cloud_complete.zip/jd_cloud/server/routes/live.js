// routes/live.js
const router = require('express').Router();
const db     = require('../config/database');
const redis  = require('../config/redis');
const { auth, optionalAuth } = require('../middleware/auth');

router.get('/active', async (req, res) => {
  try {
    const cacheKey = 'live:active:list';
    let cached = await redis.getJSON(cacheKey);
    if (cached) return res.json({ success: true, streams: cached });
    const { rows } = await db.query(
      `SELECT ls.*, u.name, u.username, u.avatar_url, u.verified
       FROM live_streams ls JOIN users u ON u.id = ls.user_id
       WHERE ls.status = 'live'
       ORDER BY ls.viewer_count DESC LIMIT 20`
    );
    await redis.setJSON(cacheKey, rows, 30);
    res.json({ success: true, streams: rows });
  } catch (err) {
    res.status(500).json({ error: 'লাইভ লোড হয়নি।' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const { rows } = await db.query(
      `SELECT ls.*, u.name, u.username, u.avatar_url
       FROM live_streams ls JOIN users u ON u.id=ls.user_id WHERE ls.id=$1`,
      [req.params.id]
    );
    if (!rows[0]) return res.status(404).json({ error: 'লাইভ পাওয়া যায়নি।' });
    res.json({ success: true, stream: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'লোড হয়নি।' });
  }
});

module.exports = router;
